<?php

namespace Less\Exception;

class ParserException extends \Exception
{

}